def multiplicacion (a,b):
    return a*b